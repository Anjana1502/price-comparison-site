from flask import Flask, render_template, request
import pandas as pd
from difflib import get_close_matches

app = Flask(__name__)

# --- Load and clean dataset ---
try:
    df = pd.read_csv('e_commerce_prices_data.csv')
    df.columns = df.columns.str.strip().str.replace(' ', '_').str.lower()
    df['product_name'] = df['product_name'].astype(str).str.strip()
    df['amazon_price_inr'] = pd.to_numeric(df['amazon_price_inr'],
                                           errors='coerce')
    df['flipkart_price_inr'] = pd.to_numeric(df['flipkart_price_inr'],
                                             errors='coerce')
    print("✅ Dataset loaded successfully.")
except Exception as e:
    print(f"❌ Error loading CSV: {e}")
    df = None


@app.route('/', methods=['GET', 'POST'])
def index():
    results = []
    product_name_query = ""
    message = ""
    suggestion = ""

    if request.method == 'POST':
        product_name_query = request.form.get('product_name', '').strip()

        if not product_name_query:
            message = "Please enter a product name."
        elif df is None:
            message = "Dataset not available."
        else:
            product_names = df['product_name'].tolist()

            # Fuzzy matching with lower cutoff
            close_matches = get_close_matches(product_name_query,
                                              product_names,
                                              n=1,
                                              cutoff=0.2)

            if close_matches:
                matched_name = close_matches[0]
                matched_row = df[df['product_name'] == matched_name].iloc[0]

                # Amazon result
                if pd.notna(matched_row['amazon_price_inr']):
                    results.append({
                        'platform':
                        'Amazon',
                        'product':
                        matched_name,
                        'price':
                        f"₹{int(matched_row['amazon_price_inr']):,}"
                    })
                else:
                    results.append({
                        'platform': 'Amazon',
                        'product': matched_name,
                        'price': "Not Available"
                    })

                # Flipkart result
                if pd.notna(matched_row['flipkart_price_inr']):
                    results.append({
                        'platform':
                        'Flipkart',
                        'product':
                        matched_name,
                        'price':
                        f"₹{int(matched_row['flipkart_price_inr']):,}"
                    })
                else:
                    results.append({
                        'platform': 'Flipkart',
                        'product': matched_name,
                        'price': "Not Available"
                    })
            else:
                suggestion = get_close_matches(product_name_query,
                                               product_names,
                                               n=1,
                                               cutoff=0.1)
                if suggestion:
                    message = f"No exact match found for '{product_name_query}'. Did you mean: '{suggestion[0]}'?"
                else:
                    message = f"No results found for '{product_name_query}'. Try fewer words or check spelling."

    return render_template("index.html",
                           results=results,
                           query=product_name_query,
                           message=message)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=81)
